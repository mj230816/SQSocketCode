//
//  AppDelegate.h
//  SQSocketClient
//
//  Created by 宋千 on 2019/6/25.
//  Copyright © 2019 SQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

