//
//  ViewController.m
//  SQSocketClient
//
//  Created by 宋千 on 2019/6/25.
//  Copyright © 2019 SQ. All rights reserved.
//

#import "ViewController.h"
#import <sys/socket.h>
#import <netinet/in.h>
#import <arpa/inet.h>

#define SQ_IP @"127.0.0.1"
#define SQ_PORT 8029
#define SQ_BUFF_MAX 1024

@interface ViewController ()

@property (nonatomic, assign) int clientId;
@property (nonatomic, assign) int restartId;

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    __weak typeof(self) weakSelf = self;
    
    [self sq_connectSocketIPv4WithIP:SQ_IP port:SQ_PORT];
    
    // 异步，否则阻塞
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        __strong typeof(self) strongSelf = weakSelf;
        [strongSelf sq_receiveMessage];
    });
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        __strong typeof(self) strongSelf = weakSelf;
        [strongSelf sq_sendMsg:@"lalala"];
    });

}


#pragma mark - connect
/**
 IPv4连接
 */
- (void)sq_connectSocketIPv4WithIP:(NSString *)ip port:(int)port {
     [self sq_connectSocketWithIP:ip port:port family:AF_INET];
}

- (void)sq_connectSocketWithIP:(NSString *)ip port:(int)port family:(int)family {
    
    const char *ipChar = ip.UTF8String;
    
    // 1.创建socket
    // socket描述符
    int sockfd;
    /**
     指定期望的通信协议（IPv4、IPv6、UDP、TCP）
     
     @param family 协议族或者成为协议域
     @param type 套接字类型
     @param protocol 协议类型常值
     @return 若成功则为非负描述符，若出错则为-1
     */
//    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    
//    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
//        NSLog(@"socket error");
//        return;
//    }
    if ((sockfd = socket(family, SOCK_STREAM, 0)) < 0) {
        NSLog(@"socket error");
        return;
    }
    
    // 2.建立连接
    // socket地址信息结构体
    struct sockaddr_in servaddr;
    // 清零操作
    bzero(&servaddr, sizeof(servaddr));
    
    // 将IP地址、端口号、协议簇赋值
    servaddr.sin_family = family;
    servaddr.sin_port = htons(port);
    /**
     将十进制数串变为正确的格式
     
     @param family 协议族或者成为协议域
     @param ip ip地址
     @param sin_addr 要存储ip地址的指针
     @return 若成功则为正数，若出错则为非正数
     */
    //    inet_pton(AF_INET, "127.0.0.1", &servaddr.sin_addr);
    if (inet_pton(family, ipChar, &servaddr.sin_addr) <= 0) {
        NSLog(@"inet_pton error for %s", ipChar);
        return;
    }
    
    /**
     socket连接
     
     @param sockfd socket描述符
     @param servaddr socket地址结构体指针
     @param addrlen socket结构体大小
     @return 若成功则0,若出错则为-1
     
     @warning 每次connect出错后必须close当前的socket连接，并重新调用socket
     */
    //    connect(sockfd, (const struct sockaddr*)&servaddr, sizeof(servaddr));
    if (connect(sockfd, (const struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        NSLog(@"connect error");
        return;
    };
    
    self.clientId = sockfd;
    NSLog(@"连接成功");
}

#pragma mark - receive
- (void)sq_receiveMessage {
    
    while (1) {
        //    char buff[1024];
        // 将数据j写到buff缓冲区里面
        uint8_t buff[1024];
        ssize_t recvLen = read(self.clientId, &buff, sizeof(buff));
        NSLog(@"接收到:%ld字节", recvLen);
        // 判断如果 0  下面会奔溃
        if (recvLen==0) {
            self.restartId ++;
            if (self.restartId>3) {
                self.restartId = 0;
                return;
            }
            NSLog(@"此次传输长度为0 如果下次还为0 请检查连接");
            continue;
        }
        
        // 数据中转换
        NSData *recvData = [NSData dataWithBytes:buff length:recvLen];
        NSString *recvStr = [[NSString alloc] initWithData:recvData encoding:NSUTF8StringEncoding];
        NSLog(@"%@",recvStr);
    }
}

- (void)sq_receiveMessage2 {
    uint8_t buff[SQ_BUFF_MAX];
    ssize_t recvLen;
    while ((recvLen = read(self.clientId, &buff, SQ_BUFF_MAX)) > 0) {
        NSLog(@"接收到:%ld字节", recvLen);
        // 数据中转换
        NSData *recvData = [NSData dataWithBytes:buff length:recvLen];
        NSString *recvStr = [[NSString alloc] initWithData:recvData encoding:NSUTF8StringEncoding];
        if (!recvStr) {
            NSLog(@"error");
        }
        NSLog(@"%@",recvStr);
    };
    if (recvLen < 0) {
        NSLog(@"error");
    }
}

#pragma mark - send

- (void)sq_sendMsg:(NSString *)msg {
    
    const char *msgChar = msg.UTF8String;
    ssize_t sendLen = write(self.clientId, msgChar, sizeof(msgChar));
    NSLog(@"发送了:%ld字节",sendLen);
}

#pragma mark - close
- (void)sq_closeSocket {
    
    if (self.clientId) {
        int close_result = close(self.clientId);
        if (close_result == -1) {
            NSLog(@"socket 关闭失败");
            return;
        }else{
            NSLog(@"socket 关闭成功");
        }
    }
}

@end
