//
//  ViewController.h
//  SQSocketClient
//
//  Created by 宋千 on 2019/6/25.
//  Copyright © 2019 SQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

